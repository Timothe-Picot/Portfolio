import github from '../assets/GitHub.png'
import miguel from '../assets/Miguel.png'
import p4 from '../assets/Puissance 4.png'
import unity from '../assets/Unity.jpg'
import quoiMaGeule from '../assets/moi.jpg'

export const projectList = [
	{
		id: '1',
		cover: miguel,
		name: "Bouh",
		date: "Juin 2023",
		desc: "Voici mon tout premier jeu vidéo. Bouh est un jeu d'horreur où vous incarnez un étudiant du crous de Lannion en pleine insomnie qui va rencontrer des phénomènes étranges en essayant de trouver un truc a manger. Étant mon tout premier jeu, je ne vous garantis pas une expérience à couper le souffle, mais j'espère pouvoir vous faire Peur/Rire. Le jeu est réalisé avec Unity et toutes les musiques sont libres de droits. Amusez-vous bien.",
		learnt: "Implémenter des conceptions simples, Elaborer des conceptions simples, Faire des essais et évaluer les résultats en regard des spécifiactions et développer des interfaces utilisateurs",
		languages: "C#, Unity",
		link: "https://play.unity.com/u/Tripotausaure",
		linkimg: unity,
		category: 'Personnel'
	},
	{
		id: '2',
		cover: p4,
		name: "Puissance 4",
		date: "Décembre 2022",
		desc: "Lors de la SAE 1.01 de ma première année de BUT Informatique, j'ai été amené à développer un puissance 4 en C qui fonctionnait dans le terminal où le joueur et une autre personne pouvaient jouer tour à tour.",
		learnt: "Implémenter des conceptions simples, Faire des essais et évaluer leurs résultats en regard des spécifications",
		languages: "C",
		link: "https://github.com/Tripotausaure/Progs_test/tree/main/Puissance%204%20Solo",
		linkimg: github,
		category: 'IUT'
	},
	{
		id: '3',
		cover: quoiMaGeule,
		name: "ZIZI",
		date: "Juin 2027",
		desc: "haha le penis c'est rigolo",
		learnt: "Sucer des bites, marquer des points",
		languages: "Oral, Anal",
		link: "https://play.unity.com/u/Tripotausaure",
		linkimg: unity,
		category: 'penis'
	},
	{
		id: '4',
		cover: miguel,
		name: "Bouh",
		date: "Juin 2023",
		desc: "Voici mon tout premier jeu vidéo. Bouh est un jeu d'horreur où vous incarnez un étudiant du crous de Lannion en pleine insomnie qui va rencontrer des phénomènes étranges en essayant de trouver un truc a manger. Étant mon tout premier jeu, je ne vous garantis pas une expérience à couper le souffle, mais j'espère pouvoir vous faire Peur/Rire. Le jeu est réalisé avec Unity et toutes les musiques sont libres de droits. Amusez-vous bien.",
		learnt: "Implémenter des conceptions simples, Elaborer des conceptions simples, Faire des essais et évaluer les résultats en regard des spécifiactions et développer des interfaces utilisateurs",
		languages: "C#, Unity",
		link: "https://play.unity.com/u/Tripotausaure",
		linkimg: unity,
		category: 'Personnel'
	},
	{
		id: '5',
		cover: p4,
		name: "Puissance 4",
		date: "Décembre 2022",
		desc: "Lors de la SAE 1.01 de ma première année de BUT Informatique, j'ai été amené à développer un puissance 4 en C qui fonctionnait dans le terminal où le joueur et une autre personne pouvaient jouer tour à tour.",
		learnt: "Implémenter des conceptions simples, Faire des essais et évaluer leurs résultats en regard des spécifications",
		languages: "C",
		link: "https://github.com/Tripotausaure/Progs_test/tree/main/Puissance%204%20Solo",
		linkimg: github,
		category: 'IUT'
	},
	{
		id: '6',
		cover: quoiMaGeule,
		name: "ZIZI",
		date: "Juin 2027",
		desc: "haha le penis c'est rigolo",
		learnt: "Sucer des bites, marquer des points",
		languages: "Oral, Anal",
		link: "https://play.unity.com/u/Tripotausaure",
		linkimg: unity,
		category: 'penis'
	},
	{
		id: '7',
		cover: miguel,
		name: "Bouh",
		date: "Juin 2023",
		desc: "Voici mon tout premier jeu vidéo. Bouh est un jeu d'horreur où vous incarnez un étudiant du crous de Lannion en pleine insomnie qui va rencontrer des phénomènes étranges en essayant de trouver un truc a manger. Étant mon tout premier jeu, je ne vous garantis pas une expérience à couper le souffle, mais j'espère pouvoir vous faire Peur/Rire. Le jeu est réalisé avec Unity et toutes les musiques sont libres de droits. Amusez-vous bien.",
		learnt: "Implémenter des conceptions simples, Elaborer des conceptions simples, Faire des essais et évaluer les résultats en regard des spécifiactions et développer des interfaces utilisateurs",
		languages: "C#, Unity",
		link: "https://play.unity.com/u/Tripotausaure",
		linkimg: unity,
		category: 'Personnel'
	},
	{
		id: '8',
		cover: p4,
		name: "Puissance 4",
		date: "Décembre 2022",
		desc: "Lors de la SAE 1.01 de ma première année de BUT Informatique, j'ai été amené à développer un puissance 4 en C qui fonctionnait dans le terminal où le joueur et une autre personne pouvaient jouer tour à tour.",
		learnt: "Implémenter des conceptions simples, Faire des essais et évaluer leurs résultats en regard des spécifications",
		languages: "C",
		link: "https://github.com/Tripotausaure/Progs_test/tree/main/Puissance%204%20Solo",
		linkimg: github,
		category: 'IUT'
	},
	{
		id: '9',
		cover: quoiMaGeule,
		name: "ZIZI",
		date: "Juin 2027",
		desc: "haha le penis c'est rigolo",
		learnt: "Sucer des bites, marquer des points",
		languages: "Oral, Anal",
		link: "https://play.unity.com/u/Tripotausaure",
		linkimg: unity,
		category: 'penis'
	},

]