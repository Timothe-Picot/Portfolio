import '../styles/Footer.css'

function Footer() {
	return (
		<footer>
			<div class="footer-container">
			<div class="contact-info">
				<h4>Contact</h4>
				<p>Téléphone : 0764169827</p>
				<p>Email : timothe.picot29@gmail.com</p>
			</div>
			<div class="cv-download">
				<a href="fichiers/CV_Timothé_Picot.pdf" download="fichiers/CV_Timothé_Picot.pdf" class="cv-button">Télécharger  mon CV</a>
			</div>
			</div>
		</footer>
	)
}

export default Footer