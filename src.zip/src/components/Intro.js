import '../styles/Intro.css'


function Intro() {
	return (
		<div className="intro">
			<p>Bonjour, mon nom est</p>
			<h1>Timothé Picot.</h1>
			<h2>Je suis étudiant en informatique.</h2>
			<p>Voici mon portfolio .</p>
			<button href="#accueil">c'est parti</button>
		</div>
		)
}

export default Intro